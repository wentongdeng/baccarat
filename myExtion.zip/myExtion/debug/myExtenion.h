//
//  myExtenion.h
//  myExtenion
//
//  Created by dengwt on 2018/2/26.
//  Copyright © 2018年 dengwt. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface myExtenion : NSObject
void MyExtesion_init(Class appDelegateClass, NSDictionary *info);
@end
